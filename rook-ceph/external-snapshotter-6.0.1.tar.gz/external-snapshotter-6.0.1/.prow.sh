#! /bin/bash

. release-tools/prow.sh

main
